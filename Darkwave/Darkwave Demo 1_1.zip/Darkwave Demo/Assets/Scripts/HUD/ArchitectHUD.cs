﻿using UnityEngine;
using System.Collections;

public class ArchitectHUD : CharacterHUD
{
	//public Architect architectScript; for use if variables are at this script child level

	// Use this for initialization
	new void Start ()
	{
		base.Start();
	}

	new void Update ()
	{
		base.Update();

	}
}
