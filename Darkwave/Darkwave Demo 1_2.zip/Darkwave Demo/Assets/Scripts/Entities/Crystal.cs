using UnityEngine;
using System.Collections;

public class Crystal : Unit {

	// Use this for initialization
	void Start () 
	{
		EntityStart();
	}
}
